DELETE FROM `#__jf_content`;
