<?php
/**
* @version $Id: mod_jdownloads_top.php v1.1 2008/29/04 20:00:00 $
* @package mod_jdownloads_top
* @copyright (C) 2007-2008 Arno Betz
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
* @author Arno Betz http://www.joomlaaddons.de
* Joomla is Free Open Source Software
*/

/** Dieses Modul zeigt die popul�rsten Downloads von jDownloads an. (Support: www.joomlaaddons.de).
*/

/** ensure this file is being included by a parent file */
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

global $database, $my;

$text_before     = trim($params->get( 'text_before' ) );
$text_after      = trim($params->get( 'text_after' ) );
$sum_view        = intval(($params->get( 'sum_view' ) ));
$sum_char        = intval(($params->get( 'sum_char' ) ));
$short_char      = ($params->get( 'short_char' ) );
$detail_view     = ($params->get( 'detail_view' ) );
$alignment       = ($params->get( 'alignment' ) );
$moduleclass_sfx = ($params->get( 'moduleclass_sfx' ) );

    if ($sum_view == 0) $sum_view = 5;
    $option = 'com_jdownloads';

    $sum_char = intval($sum_char);
    $database->setQuery("SELECT id from #__menu WHERE link = 'index.php?option=com_jdownloads'");
    $Itemid = $database->loadResult();
    if (!$Itemid) $Itemid = 999999;
    
    $access = '';
    if ($my->gid == 0) $access = '01';
    if ($my->gid == 1) $access = '11';
    if ($my->gid == 2) $access = '22';
    
    $catids = array();
    $database->setQuery("SELECT cat_id FROM #__jdownloads_cats WHERE published = 1 AND cat_access <= '$access'");
    $catids = $database->loadResultArray(0);
    $catid = implode(',', $catids);
    
    $database->setQuery("SELECT * FROM #__jdownloads_files WHERE published = 1 AND cat_id IN ($catid) ORDER BY downloads DESC");
    $files = $database->loadObjectList();
        
    $html = '';
    $html = '<table class="moduletable'.$moduleclass_sfx.'">';
    
    if ($text_before <> ''){
            $html .= '<tr><td>'.$text_before.'</td></tr>';
    }
    if ($files){
        for ($i=0; $i<$sum_view ;$i++) {
            // titell�nge begrenzen
            if ($sum_char > 0){
                $gesamt = strlen($files[$i]->file_title) + strlen($files[$i]->release);
                if (strlen($files[$i]->file_title) > $sum_char){
                   $files[$i]->file_title = substr($files[$i]->file_title, 0, $sum_char).$short_char;
                   $files[$i]->release = '';
                } else { 
                   if ($gesamt > $sum_char){
                       $files[$i]->release = ''; 
                   }    
                }    
            }    
            if ($detail_view == '1'){
                $link = sefRelToAbs('index.php?option='.$option.'&amp;Itemid='.$Itemid.'&amp;task=view.download&cid='.$files[$i]->file_id);
            } else {    
                $link = sefRelToAbs('index.php?option='.$option.'&amp;Itemid='.$Itemid.'&amp;task=viewcategory&catid='.$files[$i]->cat_id);
            }
            $link_text = '<a href="'.$link.'">'.$files[$i]->file_title.' '.$files[$i]->release.'</a>';
            $html .= '<tr valign="top"><td align="'.$alignment.'">'.$link_text.'</td><td align="right">'.$files[$i]->downloads.'</td></tr>';
        }
    }
    if ($text_after <> ''){
        $html .= '<tr><td>'.$text_after.'</td></tr>'; 
    }
    echo $html.'</table>';     
?>